# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import matplotlib.pyplot as plt
from math import sqrt
import numpy as np
from scipy.io import loadmat
from scipy import signal
from scipy.signal import find_peaks

#   o arquivo
folderS = 'H:\ic-loc-2022\ss7\semmodelo\S30_STR_A100_T0,80_'
folderC_STR = 'H:\ic-loc-2022\ss7\commodelo\S30_STR_A100_T0,80_'
folderC_DUMMY = 'H:\ic-loc-2022\ss7\commodelo\S30_DUMMY_A100_T0,80_'
folder = [folderS , folderC_STR , folderC_DUMMY]
file = ['R1.MAT','R1_100Hz.MAT','R1_4800Hz.MAT',
        'R2.MAT','R2_100Hz.MAT','R2_4800Hz.MAT',
        'R3.MAT','R3_100Hz.MAT','R3_4800Hz.MAT']
caminhos = []
for pasta in folder:
    for arquivo in file:
        caminho = pasta + arquivo
        caminhos.append(caminho)
print(caminhos)
#arquivo com as informações de cada .MAT
infos = open('Infos.txt','w')
for f in caminhos:
    d = loadmat(f)
    info1 = '\n\nArquivo:'+str(f)+'\nDados:'
    infos.write(info1)
    for key in d.keys():
        info = '\n'+str(key)+'\t'+str(type(d[key]))+'\ttamanho:'+str(len(d[key]))
        infos.write(info)
infos.close()    
 
#gráficos sem modelo

# nd.arrays para o plot
d = loadmat(caminhos[-1])
t0 = d['Channel_1_Data']
A0 = d['Channel_2_Data']
print('Entradas usadas(t,A): Channel_1_Data e Channel_2_Data','\n')

#não usar os primeiros 3000 pontos dos ndarray:
t = t0[3000:].ravel() # 'ndarray'[start:stop:step] : ou ,
A = A0[3000:].ravel() # 'ndarray'.ravel() passo o array pra 1D

dp = np.std(A.ravel())

# grafico A(t)
def graf():
    #plt.xlabel('t - canal 1')
    #plt.ylabel('A - canal 6')
    plt.plot(t,A,'r')
    #plt.axhline(y=sqrt(2)*dp)
    plt.show()

#   determinar a amplitude e periodo do sinal
#usando a função find_peaks() para pegar os indices dos picos
indices, _ = find_peaks(A) #sem esse ,_ não funciona (?)

#funções do np: mean-media; std-desvio padrão; var-variância; corrcoef-coeficiente de Person.
#amplitude
picos = A[indices]
media_A = np.mean(picos)
dp_A = np.std(picos)
var_A = np.var(picos)
CVP_A = np.corrcoef(picos)
#raiz de 2 vezes o dp(do sinal geral)
#periodo
def periodos():
    tempos = t[indices]
    Ts = []
    for i in range(len(tempos)-1):
        Ts.append(tempos[i+1]-tempos[i])
    return Ts
Ts = periodos()
media_T = np.mean(Ts)
dp_T = np.std(Ts)
var_T = np.var(Ts)
CVP_T = np.corrcoef(Ts)

#   resulados
print( 'Valores de amplitude e periodo e seu desvio padrão')
print( 'Média das Amplitudes:', media_A,', dp:', dp_A,
       '\nMédia dos Periodos:', media_T,', dp:', dp_T,'\n',
       'Amplitude:', sqrt(2)*dp) #desvio padrão do sinal * raiz de 2
graf()

'''
A média - ainda que considerada como um número
que tem a faculdade de representar uma série de valores -
não pode, por si mesma, destacar o grau de homogeneidade
ou heterogeneidade que existe entre os valores que compõem o conjunto.

'''